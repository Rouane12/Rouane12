---
name: Feature request
about: Suggest an idea for this project
title: "[Feature request]"
labels: ""
assignees: ""
---

---

name: 🚀 Feature request
about: If you have a feature request 💡

---

**Context**

What are you trying to do and how would you want to do it differently? Is it something you currently you cannot do? Is this related to an issue/problem?

**Alternatives**

Can you achieve the same result doing it in an alternative way? Is the alternative considerable?

**Has the feature been requested before?**

Please provide a link to the issue.

**If the feature request is approved, would you be willing to submit a PR?**

Yes / No _(Help can be provided if you need assistance submitting a PR)_
